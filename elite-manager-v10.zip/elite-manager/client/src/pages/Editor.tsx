import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { useDarkMode } from "@/contexts/DarkModeContext";
import { teams, Team, Player } from "@/lib/teams";
import { teamLogos } from "@/lib/teamLogos";

type EditorSection = "players" | "clubs";

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function clamp(v: number, min: number, max: number) { return Math.max(min, Math.min(max, v)); }

const POSITIONS = ["GK","CB","LB","RB","CDM","CM","CAM","LM","RM","LW","RW","ST"];
const PERSONALITIES = ["leader","professional","temperamental","quiet","ambitious"];
const FEET = ["Direito","Esquerdo","Ambidestro"];
const NATIONALITIES = ["Brasil","Argentina","Uruguai","Colômbia","Paraguai","Chile","Equador","Peru","Venezuela","Portugal","Espanha","França","Alemanha","Itália","Holanda","Bélgica","Inglaterra","Grécia","Dinamarca"];

// ─── PLAYER EDITOR MODAL ─────────────────────────────────────────────────────

function PlayerEditor({ player, dark, onSave, onClose }: {
  player: Player; dark: boolean;
  onSave: (p: Player) => void;
  onClose: () => void;
}) {
  const [p, setP] = useState<Player>({ ...player });

  const bg  = dark ? "bg-gray-900 border-gray-700" : "bg-white border-gray-200";
  const tx  = dark ? "text-white"  : "text-gray-900";
  const sub = dark ? "text-gray-400" : "text-gray-500";
  const inp = dark
    ? "bg-gray-800 border-gray-700 text-white placeholder-gray-500"
    : "bg-white border-gray-300 text-gray-900 placeholder-gray-400";

  const num = (key: keyof Player, min: number, max: number) => (
    <div className="flex items-center gap-2">
      <input type="range" min={min} max={max} value={Number(p[key])}
        onChange={e => setP(prev => ({ ...prev, [key]: Number(e.target.value) }))}
        className="flex-1 h-1.5 rounded accent-green-500"/>
      <span className={`text-sm font-bold w-8 text-right ${tx}`}>{Number(p[key])}</span>
    </div>
  );

  const attrColor = (v: number) =>
    v >= 80 ? "text-green-400" : v >= 65 ? "text-yellow-400" : "text-red-400";

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-end justify-center">
      <div className={`w-full max-w-lg rounded-t-2xl border-t border-x p-5 overflow-y-auto max-h-[92vh] ${bg}`}>

        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h2 className={`text-lg font-bold ${tx}`}>Editar Jogador</h2>
          <div className="flex gap-2">
            <button onClick={() => onSave(p)}
              className="px-4 py-2 bg-green-600 text-white text-xs font-bold rounded-lg">Salvar</button>
            <button onClick={onClose}
              className={`px-3 py-2 text-xs rounded-lg border ${dark?"border-gray-700 text-gray-400":"border-gray-300 text-gray-500"}`}>✕</button>
          </div>
        </div>

        {/* IDENTIDADE */}
        <p className={`text-xs font-bold uppercase tracking-wider ${sub} mb-2`}>Identidade</p>
        <div className="space-y-2 mb-4">
          <input value={p.name} onChange={e=>setP(prev=>({...prev,name:e.target.value}))}
            placeholder="Nome" className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}/>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className={`text-xs ${sub} mb-1 block`}>Posição principal</label>
              <select value={p.position} onChange={e=>setP(prev=>({...prev,position:e.target.value}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}>
                {POSITIONS.map(pos=><option key={pos}>{pos}</option>)}
              </select>
            </div>
            <div>
              <label className={`text-xs ${sub} mb-1 block`}>Idade</label>
              <input type="number" min={15} max={45} value={p.age}
                onChange={e=>setP(prev=>({...prev,age:Number(e.target.value)}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}/>
            </div>
            <div>
              <label className={`text-xs ${sub} mb-1 block`}>Altura (cm)</label>
              <input type="number" min={155} max={210} value={p.height}
                onChange={e=>setP(prev=>({...prev,height:Number(e.target.value)}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}/>
            </div>
            <div>
              <label className={`text-xs ${sub} mb-1 block`}>Personalidade</label>
              <select value={p.personality} onChange={e=>setP(prev=>({...prev,personality:e.target.value as any}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}>
                {PERSONALITIES.map(x=><option key={x}>{x}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* HABILIDADE */}
        <p className={`text-xs font-bold uppercase tracking-wider ${sub} mb-2`}>Habilidade</p>
        <div className={`rounded-xl border p-3 mb-4 ${dark?"border-gray-700":"border-gray-200"}`}>
          <div className="grid grid-cols-2 gap-3 mb-3 text-center">
            <div>
              <div className={`text-3xl font-black ${attrColor(p.overall)}`}>{p.overall}</div>
              <div className={`text-xs ${sub}`}>OVR Atual</div>
            </div>
            <div>
              <div className={`text-3xl font-black ${dark?"text-blue-300":"text-blue-600"}`}>{p.potential}</div>
              <div className={`text-xs ${sub}`}>Potencial</div>
            </div>
          </div>
          <div className="space-y-2">
            {[
              {label:"OVR", key:"overall", min:40, max:99},
              {label:"Potencial", key:"potential", min:40, max:99},
            ].map(({label,key,min,max})=>(
              <div key={key}>
                <div className="flex justify-between mb-0.5">
                  <span className={`text-xs ${sub}`}>{label}</span>
                </div>
                {num(key as keyof Player, min, max)}
              </div>
            ))}
          </div>
        </div>

        {/* ATRIBUTOS */}
        <p className={`text-xs font-bold uppercase tracking-wider ${sub} mb-2`}>Atributos</p>
        <div className={`rounded-xl border p-3 mb-4 ${dark?"border-gray-700":"border-gray-200"}`}>
          <div className="space-y-2.5">
            {([
              {label:"🟢 Velocidade",   key:"pace",      color:"text-green-400"},
              {label:"🔴 Finalização",  key:"shooting",  color:"text-red-400"},
              {label:"🔵 Passe",        key:"passing",   color:"text-blue-400"},
              {label:"🟡 Drible",       key:"dribbling", color:"text-yellow-400"},
              {label:"🟠 Defesa",       key:"defense",   color:"text-orange-400"},
              {label:"⚪ Físico",       key:"physical",  color:"text-gray-300"},
            ] as {label:string;key:keyof Player;color:string}[]).map(({label,key,color})=>(
              <div key={key as string}>
                <div className="flex justify-between mb-0.5">
                  <span className={`text-xs ${sub}`}>{label}</span>
                  <span className={`text-xs font-bold ${color}`}>{Number(p[key])}</span>
                </div>
                {num(key, 1, 99)}
              </div>
            ))}
          </div>
        </div>

        {/* CONTRATO */}
        <p className={`text-xs font-bold uppercase tracking-wider ${sub} mb-2`}>Contrato</p>
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div>
            <label className={`text-xs ${sub} mb-1 block`}>Salário (K/mês)</label>
            <input type="number" min={1} max={5000} value={p.salary}
              onChange={e=>setP(prev=>({...prev,salary:Number(e.target.value)}))}
              className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}/>
          </div>
          <div>
            <label className={`text-xs ${sub} mb-1 block`}>Anos de contrato</label>
            <select value={p.contractYears} onChange={e=>setP(prev=>({...prev,contractYears:Number(e.target.value)}))}
              className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}>
              {[1,2,3,4,5].map(n=><option key={n}>{n}</option>)}
            </select>
          </div>
        </div>

        {/* CONDIÇÃO */}
        <p className={`text-xs font-bold uppercase tracking-wider ${sub} mb-2`}>Condição</p>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className={`text-xs ${sub} mb-1 block`}>Fadiga (%)</label>
            {num("fatigue", 0, 100)}
          </div>
          <div>
            <label className={`text-xs ${sub} mb-1 block`}>Moral (%)</label>
            {num("morale", 0, 100)}
          </div>
        </div>

      </div>
    </div>
  );
}

// ─── CLUB EDITOR MODAL ───────────────────────────────────────────────────────

function ClubEditor({ team, dark, onSave, onClose }: {
  team: Team; dark: boolean;
  onSave: (t: Team) => void;
  onClose: () => void;
}) {
  const [t, setT] = useState<Team>({ ...team });

  const bg  = dark ? "bg-gray-900 border-gray-700" : "bg-white border-gray-200";
  const tx  = dark ? "text-white"  : "text-gray-900";
  const sub = dark ? "text-gray-400" : "text-gray-500";
  const inp = dark
    ? "bg-gray-800 border-gray-700 text-white"
    : "bg-white border-gray-300 text-gray-900";

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-end justify-center">
      <div className={`w-full max-w-lg rounded-t-2xl border-t border-x p-5 overflow-y-auto max-h-[80vh] ${bg}`}>
        <div className="flex items-center justify-between mb-4">
          <h2 className={`text-lg font-bold ${tx}`}>Editar Clube</h2>
          <div className="flex gap-2">
            <button onClick={() => onSave(t)}
              className="px-4 py-2 bg-green-600 text-white text-xs font-bold rounded-lg">Salvar</button>
            <button onClick={onClose}
              className={`px-3 py-2 text-xs rounded-lg border ${dark?"border-gray-700 text-gray-400":"border-gray-300 text-gray-500"}`}>✕</button>
          </div>
        </div>

        <div className="space-y-3">
          {[
            {label:"Nome do clube", key:"name"},
            {label:"Abreviação (3 letras)", key:"abbreviation"},
            {label:"Cidade", key:"city"},
            {label:"Objetivo da temporada", key:"objective"},
          ].map(({label,key})=>(
            <div key={key}>
              <label className={`text-xs ${sub} mb-1 block`}>{label}</label>
              <input value={String((t as any)[key])}
                onChange={e=>setT(prev=>({...prev,[key]:e.target.value}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}/>
            </div>
          ))}

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className={`text-xs ${sub} mb-1 block`}>Nível (1–4)</label>
              <select value={t.clubLevel} onChange={e=>setT(prev=>({...prev,clubLevel:Number(e.target.value) as any}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}>
                <option value={1}>1 — Pequeno</option>
                <option value={2}>2 — Médio</option>
                <option value={3}>3 — Grande</option>
                <option value={4}>4 — Gigante</option>
              </select>
            </div>
            <div>
              <label className={`text-xs ${sub} mb-1 block`}>Saldo (K)</label>
              <input type="number" value={t.balance}
                onChange={e=>setT(prev=>({...prev,balance:Number(e.target.value)}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}/>
            </div>
            <div>
              <label className={`text-xs ${sub} mb-1 block`}>Receita mensal (K)</label>
              <input type="number" value={t.monthlyIncome}
                onChange={e=>setT(prev=>({...prev,monthlyIncome:Number(e.target.value)}))}
                className={`w-full px-3 py-2 rounded-lg border text-sm ${inp}`}/>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── EDITOR PRINCIPAL ─────────────────────────────────────────────────────────

export default function Editor() {
  const { isDarkMode } = useDarkMode();
  const [, navigate] = useLocation();
  const [section, setSection] = useState<EditorSection>("players");
  const [search, setSearch]   = useState("");
  const [selectedTeam, setSelectedTeam] = useState<Team>(teams[0]);
  const [editingPlayer, setEditingPlayer] = useState<Player|null>(null);
  const [editingClub, setEditingClub]     = useState<Team|null>(null);
  // Estado local editável dos times (não persiste no jogo, só no editor)
  const [editedTeams, setEditedTeams] = useState<Team[]>(teams.map(t=>({...t})));

  const dark = isDarkMode;
  const bg   = dark ? "bg-gray-950" : "bg-gray-50";
  const card = dark ? "bg-gray-900 border-gray-800" : "bg-white border-gray-200";
  const tx   = dark ? "text-white"  : "text-gray-900";
  const sub  = dark ? "text-gray-400" : "text-gray-500";
  const divider = dark ? "border-gray-800" : "border-gray-200";

  const currentTeam = editedTeams.find(t=>t.id===selectedTeam.id) ?? selectedTeam;

  const filteredPlayers = useMemo(()=>
    currentTeam.players.filter(p=>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.position.toLowerCase().includes(search.toLowerCase())
    ),[currentTeam, search]);

  const filteredTeams = useMemo(()=>
    editedTeams.filter(t=>
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.city.toLowerCase().includes(search.toLowerCase()) ||
      t.abbreviation.toLowerCase().includes(search.toLowerCase())
    ),[editedTeams, search]);

  function savePlayer(updated: Player) {
    setEditedTeams(prev => prev.map(t =>
      t.id !== currentTeam.id ? t : {
        ...t,
        players: t.players.map(p => p.id === updated.id ? updated : p)
      }
    ));
    setEditingPlayer(null);
  }

  function saveClub(updated: Team) {
    setEditedTeams(prev => prev.map(t => t.id === updated.id ? {...updated, players: t.players} : t));
    if (selectedTeam.id === updated.id) setSelectedTeam(updated);
    setEditingClub(null);
  }

  const attrColor = (v: number) =>
    v >= 80 ? (dark?"text-green-400":"text-green-600")
    : v >= 70 ? (dark?"text-blue-400":"text-blue-600")
    : (dark?"text-gray-400":"text-gray-500");

  return (
    <div className={`min-h-screen flex flex-col ${bg}`}>

      {/* Modals */}
      {editingPlayer && (
        <PlayerEditor player={editingPlayer} dark={dark}
          onSave={savePlayer} onClose={()=>setEditingPlayer(null)}/>
      )}
      {editingClub && (
        <ClubEditor team={editingClub} dark={dark}
          onSave={saveClub} onClose={()=>setEditingClub(null)}/>
      )}

      {/* Header */}
      <div className={`sticky top-0 z-40 ${dark?"bg-gray-950 border-gray-800":"bg-white border-gray-200"} border-b px-4 py-4 flex items-center justify-between`}>
        <button onClick={()=>navigate("/")} className={`text-sm font-medium ${sub}`}>← Voltar</button>
        <h1 className={`text-base font-bold ${tx}`}>Editor</h1>
        <div className="w-16"/>
      </div>

      {/* Tabs */}
      <div className={`flex border-b ${divider} ${dark?"bg-gray-950":"bg-white"}`}>
        {([
          {key:"players", label:"👤 Jogadores"},
          {key:"clubs",   label:"🏟️ Clubes"},
        ] as {key:EditorSection;label:string}[]).map(tab=>(
          <button key={tab.key} onClick={()=>{ setSection(tab.key); setSearch(""); }}
            className={`flex-1 py-3 text-sm font-semibold transition-colors ${
              section===tab.key
                ? dark?"border-b-2 border-white text-white":"border-b-2 border-gray-900 text-gray-900"
                : sub
            }`}>
            {tab.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto pb-10 max-w-lg mx-auto w-full px-4 pt-4">

        {/* ── JOGADORES ──────────────────────────────────────────────── */}
        {section === "players" && (
          <div>
            {/* Seletor de time */}
            <div className="mb-3">
              <select value={selectedTeam.id}
                onChange={e=>{
                  const t=editedTeams.find(t=>t.id===Number(e.target.value));
                  if(t) setSelectedTeam(t);
                  setSearch("");
                }}
                className={`w-full px-3 py-2.5 rounded-xl border text-sm font-semibold ${
                  dark?"bg-gray-900 border-gray-700 text-white":"bg-white border-gray-300 text-gray-900"
                }`}>
                {editedTeams.map(t=>(
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>

            {/* Busca */}
            <input type="text" placeholder="Buscar jogador..." value={search}
              onChange={e=>setSearch(e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-sm mb-3 ${
                dark?"bg-gray-900 border-gray-700 text-white placeholder-gray-500":"bg-white border-gray-300 text-gray-900 placeholder-gray-400"
              }`}/>

            {/* Info do time */}
            <div className={`rounded-xl border p-3 mb-3 flex items-center gap-3 ${card}`}>
              <div className="w-10 h-10">{teamLogos[currentTeam.id]}</div>
              <div>
                <p className={`text-sm font-bold ${tx}`}>{currentTeam.name}</p>
                <p className={`text-xs ${sub}`}>{filteredPlayers.length} jogadores</p>
              </div>
              <button onClick={()=>setEditingClub(currentTeam)}
                className={`ml-auto text-xs px-3 py-1.5 rounded-lg border ${dark?"border-gray-700 text-gray-300":"border-gray-300 text-gray-600"}`}>
                Editar clube
              </button>
            </div>

            {/* Lista de jogadores */}
            <div className={`rounded-xl border overflow-hidden ${card}`}>
              {filteredPlayers.map((player, idx) => (
                <button key={player.id} onClick={()=>setEditingPlayer(player)}
                  className={`w-full flex items-center gap-3 px-4 py-3 border-b last:border-0 text-left transition-colors active:opacity-70 ${divider} ${dark?"hover:bg-gray-800":"hover:bg-gray-50"}`}>
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${dark?"bg-gray-700 text-gray-200":"bg-gray-100 text-gray-700"}`}>
                    {player.position}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-semibold truncate ${tx}`}>{player.name}</p>
                    <p className={`text-xs ${sub}`}>{player.age}a · {player.height}cm</p>
                  </div>
                  <span className={`text-sm font-black ${attrColor(player.overall)}`}>{player.overall}</span>
                  <span className={`text-xs ${sub} ml-1`}>›</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ── CLUBES ─────────────────────────────────────────────────── */}
        {section === "clubs" && (
          <div>
            <input type="text" placeholder="Buscar clube..." value={search}
              onChange={e=>setSearch(e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-sm mb-3 ${
                dark?"bg-gray-900 border-gray-700 text-white placeholder-gray-500":"bg-white border-gray-300 text-gray-900 placeholder-gray-400"
              }`}/>

            <div className={`rounded-xl border overflow-hidden ${card}`}>
              {filteredTeams.map(team => (
                <button key={team.id} onClick={()=>setEditingClub(team)}
                  className={`w-full flex items-center gap-3 px-4 py-3 border-b last:border-0 text-left transition-colors ${divider} ${dark?"hover:bg-gray-800":"hover:bg-gray-50"}`}>
                  <div className="w-10 h-10 flex-shrink-0">{teamLogos[team.id]}</div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-semibold ${tx}`}>{team.name}</p>
                    <p className={`text-xs ${sub}`}>{team.city} · Nível {team.clubLevel}</p>
                    <p className={`text-xs ${sub}`}>{team.objective}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className={`text-xs font-bold ${dark?"text-green-400":"text-green-600"}`}>
                      R${team.balance.toLocaleString()}K
                    </p>
                    <p className={`text-xs ${sub}`}>{team.players.length} jog.</p>
                  </div>
                  <span className={`text-xs ${sub} ml-1`}>›</span>
                </button>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
