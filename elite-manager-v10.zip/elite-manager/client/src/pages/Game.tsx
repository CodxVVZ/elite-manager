import { useState, useMemo, useEffect } from "react";
import { useLocation } from "wouter";
import { useDarkMode } from "@/contexts/DarkModeContext";
import { useGame } from "@/contexts/GameContext";
import { teams as allTeams } from "@/lib/teams";
import { simulateMatch, defaultTactics, TacticalSettings } from "@/lib/matchEngine";
import { sortStandings } from "@/lib/leagueSystem";
import MatchScreen, { SubstitutionRecord } from "@/pages/MatchScreen";
import { teamLogos } from "@/lib/teamLogos";
import { saveGame, loadSettings } from "@/lib/saveSystem";

// ─── TIPOS ────────────────────────────────────────────────────────────────────

type Tab = "dashboard"|"squad"|"tactics"|"training"|"finances"|"competitions"|"transfers"|"news"|"history";
type TrainingFocus = "physical"|"technical"|"tactical"|"rest"|"youth";
type TrainingIntensity = "light"|"normal"|"hard";
export type Formation = "4-4-2"|"4-3-3"|"4-2-3-1"|"3-5-2"|"5-3-2"|"4-5-1";

// ─── FORMAÇÕES ────────────────────────────────────────────────────────────────

const formationRows: Record<Formation, string[][]> = {
  "4-4-2":   [["GK"],["LB","CB","CB","RB"],["LM","CM","CM","RM"],["ST","ST"]],
  "4-3-3":   [["GK"],["LB","CB","CB","RB"],["CM","CM","CM"],["LW","ST","RW"]],
  "4-2-3-1": [["GK"],["LB","CB","CB","RB"],["CDM","CDM"],["LM","CAM","RM"],["ST"]],
  "3-5-2":   [["GK"],["CB","CB","CB"],["LM","CM","CM","CM","RM"],["ST","ST"]],
  "5-3-2":   [["GK"],["LB","CB","CB","CB","RB"],["CM","CM","CM"],["ST","ST"]],
  "4-5-1":   [["GK"],["LB","CB","CB","RB"],["LM","CM","CDM","CM","RM"],["ST"]],
};

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function fmtMoney(v: number) { return v>=1000?`${(v/1000).toFixed(1)}M`:`${v}K`; }
function levelLabel(l: number) { return ["","Pequeno","Médio","Grande","Gigante"][l]??""; }
function statusLabel(s: string) {
  const m: Record<string,string>={star:"Estrela",starter:"Titular",rotation:"Rotação",reserve:"Reserva",prospect:"Promessa"};
  return m[s]??s;
}
function fatigueColor(v: number, d: boolean) {
  return v>=70?(d?"text-green-400":"text-green-600"):v>=40?(d?"text-yellow-400":"text-yellow-600"):(d?"text-red-400":"text-red-600");
}
function moraleColor(v: number, d: boolean) {
  return v>=70?(d?"text-green-400":"text-green-600"):v>=45?(d?"text-yellow-400":"text-yellow-600"):(d?"text-red-400":"text-red-600");
}
function moraleLabel(v: number) {
  return v>=85?"Excelente":v>=70?"Bom":v>=50?"Normal":v>=30?"Baixo":"Péssimo";
}
function happyLabel(v: number) {
  return v>=85?"Feliz":v>=65?"Satisfeito":v>=45?"Neutro":v>=25?"Insatisfeito":"Revoltado";
}

// ─── CAMPO TÁTICO COM BLOCOS ──────────────────────────────────────────────────

function FormationField({ formation, dark }: { formation: Formation; dark: boolean }) {
  const rows = formationRows[formation];
  return (
    <div className="relative w-full rounded-xl overflow-hidden"
      style={{background:"linear-gradient(180deg,#1a4a1a 0%,#2a6a2a 50%,#1a4a1a 100%)",minHeight:"200px"}}>

      {/* Linhas do campo */}
      <div className="absolute inset-x-0 top-1/2 h-px bg-white opacity-20"/>
      <div className="absolute top-1/2 left-1/2 w-16 h-16 border border-white opacity-10 rounded-full -translate-x-1/2 -translate-y-1/2"/>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-8 border-b border-l border-r border-white opacity-15 rounded-b-lg"/>
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-24 h-8 border-t border-l border-r border-white opacity-15 rounded-t-lg"/>

      {/* Blocos de posições — de baixo (GK) para cima (atacantes) */}
      <div className="relative flex flex-col justify-around h-full py-2 px-2" style={{minHeight:"200px"}}>
        {[...rows].reverse().map((row, rowIdx) => (
          <div key={rowIdx} className="flex justify-around items-center">
            {row.map((pos, posIdx) => (
              <div key={posIdx}
                className="flex flex-col items-center justify-center rounded-lg text-xs font-bold"
                style={{
                  width:`${Math.min(56, 90/row.length)}px`,
                  height:"32px",
                  background: pos==="GK"
                    ? "rgba(234,179,8,0.7)"
                    : pos.includes("B")
                    ? "rgba(59,130,246,0.7)"
                    : pos.includes("M")||pos.includes("D")
                    ? "rgba(16,185,129,0.7)"
                    : "rgba(239,68,68,0.7)",
                  boxShadow:"0 2px 6px rgba(0,0,0,0.4)",
                }}>
                <span className="text-white text-xs leading-tight">{pos}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── CARD JOGADOR ─────────────────────────────────────────────────────────────

function PlayerCard({ player, state, dark, onClose }: { player:any; state:any; dark:boolean; onClose:()=>void; }) {
  const bg = dark?"bg-gray-800 border-gray-700":"bg-white border-gray-200";
  const tx = dark?"text-white":"text-gray-900";
  const sub = dark?"text-gray-400":"text-gray-500";

  function bar(label: string, val: number) {
    return (
      <div key={label} className="mb-1.5">
        <div className="flex justify-between text-xs mb-0.5">
          <span className={sub}>{label}</span>
          <span className={`font-bold ${tx}`}>{val}</span>
        </div>
        <div className={`h-1.5 rounded-full ${dark?"bg-gray-700":"bg-gray-200"}`}>
          <div className="h-1.5 rounded-full bg-green-500" style={{width:`${((val-50)/50)*100}%`}}/>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 px-4 pb-6">
      <div className={`w-full max-w-md rounded-2xl border p-5 ${bg}`}>
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className={`text-lg font-bold ${tx}`}>{player.name}</p>
            <p className={`text-xs ${sub}`}>{player.position} · {player.age}a · {player.height}cm</p>
          </div>
          <button onClick={onClose} className={`text-xl ${sub}`}>✕</button>
        </div>
        <div className="flex gap-2 mb-4 text-xs">
          {[
            {label:"OVR", val:player.overall, color:tx},
            {label:"POT", val:player.potential, color:dark?"text-blue-300":"text-blue-600"},
            {label:"Cond", val:`${state?.fatigue??100}%`, color:fatigueColor(state?.fatigue??100,dark)},
          ].map(item=>(
            <div key={item.label} className={`flex-1 rounded-lg p-2 text-center ${dark?"bg-gray-700":"bg-gray-100"}`}>
              <div className={`text-2xl font-black ${item.color}`}>{item.val}</div>
              <div className={sub}>{item.label}</div>
            </div>
          ))}
        </div>
        {bar("Velocidade",player.pace)}
        {bar("Finalização",player.shooting)}
        {bar("Passe",player.passing)}
        {bar("Drible",player.dribbling)}
        {bar("Defesa",player.defense)}
        {bar("Físico",player.physical)}
        <div className={`mt-3 pt-3 border-t ${dark?"border-gray-700":"border-gray-200"} grid grid-cols-2 gap-1 text-xs`}>
          <div><span className={sub}>Status: </span><span className={tx}>{statusLabel(player.status)}</span></div>
          <div><span className={sub}>Salário: </span><span className={tx}>{fmtMoney(player.salary)}/mês</span></div>
          <div><span className={sub}>Contrato: </span><span className={tx}>{player.contractYears} ano(s)</span></div>
          <div><span className={sub}>Moral: </span><span className={moraleColor(state?.morale??75,dark)}>{moraleLabel(state?.morale??75)}</span></div>
          <div><span className={sub}>Felicidade: </span><span className={dark?"text-yellow-400":"text-yellow-600"}>{happyLabel(state?.happiness??75)}</span></div>
          {(state?.injuryWeeks??0)>0 && <div className="col-span-2 text-red-400">🤕 Lesionado: {state.injuryWeeks} semana(s)</div>}
        </div>
      </div>
    </div>
  );
}

// ─── TÁTICAS ─────────────────────────────────────────────────────────────────

function TacticsPanel({ tactics, setTactics, dark }: {
  tactics: TacticalSettings; setTactics:(t:TacticalSettings)=>void; dark:boolean;
}) {
  const sub = dark?"text-gray-400":"text-gray-600";
  const btn = (active: boolean) =>
    `px-3 py-1.5 rounded-lg text-xs font-semibold ${active?"bg-white text-black":dark?"bg-gray-700 text-gray-300":"bg-gray-200 text-gray-700"}`;

  function row(label:string, desc:string, node:React.ReactNode) {
    return (
      <div className={`py-3 border-b ${dark?"border-gray-700/50":"border-gray-200"}`}>
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className={`text-xs font-semibold ${dark?"text-gray-200":"text-gray-800"}`}>{label}</p>
            <p className={`text-xs ${sub}`}>{desc}</p>
          </div>
          <div className="flex gap-1 flex-shrink-0">{node}</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {row("Mentalidade","Postura geral",<>
        {(["defensive","balanced","attacking"] as const).map(v=>(
          <button key={v} className={btn(tactics.mentality===v)} onClick={()=>setTactics({...tactics,mentality:v})}>
            {v==="defensive"?"Def":v==="balanced"?"Equil":"Ataq"}
          </button>
        ))}
      </>)}
      {row("Linha defensiva","Altura da defesa",<>
        {(["deep","medium","high"] as const).map(v=>(
          <button key={v} className={btn(tactics.defensiveLine===v)} onClick={()=>setTactics({...tactics,defensiveLine:v})}>
            {v==="deep"?"Baixa":v==="medium"?"Média":"Alta"}
          </button>
        ))}
      </>)}
      {row("Pressão","Intensidade da marcação",<>
        {(["low","medium","high"] as const).map(v=>(
          <button key={v} className={btn(tactics.pressingIntensity===v)} onClick={()=>setTactics({...tactics,pressingIntensity:v})}>
            {v==="low"?"Baixa":v==="medium"?"Média":"Alta"}
          </button>
        ))}
      </>)}
      {row("Estilo","Forma de jogar",<>
        {(["direct","balanced","possession"] as const).map(v=>(
          <button key={v} className={btn(tactics.playStyle===v)} onClick={()=>setTactics({...tactics,playStyle:v})}>
            {v==="direct"?"Direto":v==="balanced"?"Equil":"Posse"}
          </button>
        ))}
      </>)}
      {row("Largura ofensiva","Amplitude do ataque",<>
        {(["narrow","balanced","wide"] as const).map(v=>(
          <button key={v} className={btn(tactics.offensiveWidth===v)} onClick={()=>setTactics({...tactics,offensiveWidth:v})}>
            {v==="narrow"?"Estr":v==="balanced"?"Normal":"Aberta"}
          </button>
        ))}
      </>)}
      {row("Contra-ataque","Explorar espaços",<>
        <button className={btn(tactics.counterAttack)} onClick={()=>setTactics({...tactics,counterAttack:true})}>Sim</button>
        <button className={btn(!tactics.counterAttack)} onClick={()=>setTactics({...tactics,counterAttack:false})}>Não</button>
      </>)}
      {row("Apoio lateral","Laterais no ataque",<>
        <button className={btn(tactics.fullbackSupport)} onClick={()=>setTactics({...tactics,fullbackSupport:true})}>Sim</button>
        <button className={btn(!tactics.fullbackSupport)} onClick={()=>setTactics({...tactics,fullbackSupport:false})}>Não</button>
      </>)}
      {row("Compactação","Bloco defensivo",<>
        <button className={btn(tactics.compactDefense)} onClick={()=>setTactics({...tactics,compactDefense:true})}>Sim</button>
        <button className={btn(!tactics.compactDefense)} onClick={()=>setTactics({...tactics,compactDefense:false})}>Não</button>
      </>)}
    </div>
  );
}

// ─── COMPONENTE PRINCIPAL ─────────────────────────────────────────────────────

export default function Game() {
  const dark = useDarkMode().isDarkMode;
  const {
    selectedTeam, playerStates,
    tactics, setTactics,
    matchHistory, addMatchRecord, currentRound, advanceRound,
    balance, monthlyIncome, wageBill, addFunds,
    standings, recordLeagueResult,
    news, addNews,
    trainingFocus, setTrainingFocus,
    trainingIntensity, setTrainingIntensity,
    applyTraining, applyFatigueDrops,
    season, buildSaveData,
  } = useGame();
  const settings = loadSettings();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [matchData, setMatchData] = useState<ReturnType<typeof simulateMatch>|null>(null);
  const [opponent, setOpponent] = useState<typeof allTeams[0]|null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPlayer, setSelectedPlayer] = useState<any>(null);
  const [formation, setFormation] = useState<Formation>("4-4-2");
  const [trainingDone, setTrainingDone] = useState(false);
  const [squadSort, setSquadSort] = useState<"name"|"position"|"overall"|"salary"|"fatigue"|"age">("overall");
  const [lineup, setLineup] = useState<number[]>([]);           // IDs dos 11 titulares escolhidos
  const [lineupMode, setLineupMode] = useState<"auto"|"manual">("auto");
  const [showContractModal, setShowContractModal] = useState<any>(null);

  const [saveSlotModal, setSaveSlotModal] = useState(false);
  const [lastSaveMsg, setLastSaveMsg] = useState<string|null>(null);

  function handleManualSave(slot: number) {
    const data = buildSaveData();
    if (!data || !selectedTeam) return;
    saveGame(slot, data, selectedTeam.name, selectedTeam.abbreviation);
    setSaveSlotModal(false);
    setLastSaveMsg(`Salvo no Slot ${slot}`);
    setTimeout(() => setLastSaveMsg(null), 2500);
  }
    if(!selectedTeam) return null;
    const others = allTeams.filter(t=>t.id!==selectedTeam.id);
    return others[currentRound % others.length];
  },[selectedTeam,currentRound]);

  if(!selectedTeam) return (
    <div className={`min-h-screen flex items-center justify-center ${dark?"bg-gray-900":"bg-white"}`}>
      <div className="text-center px-8">
        <p className={`text-lg mb-4 ${dark?"text-white":"text-black"}`}>Nenhum time selecionado</p>
        <button onClick={()=>navigate("/new-game")} className="bg-green-600 text-white px-6 py-2 rounded-lg font-bold">
          Escolher Time
        </button>
      </div>
    </div>
  );

  // ── CORES ────────────────────────────────────────────────────────────────
  const bg    = dark?"bg-gray-900":"bg-gray-50";
  const card  = dark?"bg-gray-800 border-gray-700":"bg-white border-gray-200";
  const tx    = dark?"text-white":"text-gray-900";
  const sub   = dark?"text-gray-400":"text-gray-500";
  const div   = dark?"border-gray-700":"border-gray-200";

  // ── SIMULAR PARTIDAS DA IA ───────────────────────────────────────────────
  function simulateAIRound() {
    const others = [...allTeams.filter(t=>t.id!==selectedTeam.id)];
    // Embaralhar
    for(let i=others.length-1;i>0;i--){
      const j=Math.floor(Math.random()*(i+1));
      [others[i],others[j]]=[others[j],others[i]];
    }
    // Simular pares (19 times → 9 jogos + 1 bye)
    for(let i=0;i<others.length-1;i+=2){
      const home=others[i], away=others[i+1];
      const aiH={...defaultTactics};
      const aiA={...defaultTactics};
      const r1=Math.random();
      aiH.mentality=r1<0.4?"attacking":r1<0.7?"balanced":"defensive";
      const r2=Math.random();
      aiA.mentality=r2<0.4?"attacking":r2<0.7?"balanced":"defensive";
      const hFat: Record<number,number>={};
      home.players.forEach(p=>{hFat[p.id]=100;});
      const aFat: Record<number,number>={};
      away.players.forEach(p=>{aFat[p.id]=100;});
      const res=simulateMatch(home,away,hFat,aFat,aiH,aiA);
      recordLeagueResult(home.id,away.id,res.homeGoals,res.awayGoals);
    }
  }

  // ── INICIAR PARTIDA ──────────────────────────────────────────────────────
  function handleContinue() {
    if(!nextOpponent) return;
    const homeFat: Record<number,number>={};
    selectedTeam.players.forEach(p=>{homeFat[p.id]=playerStates[p.id]?.fatigue??100;});
    const awayFat: Record<number,number>={};
    nextOpponent.players.forEach(p=>{awayFat[p.id]=100;});
    const aiT={...defaultTactics};
    const r=Math.random();
    aiT.mentality=r<0.4?"attacking":r<0.7?"balanced":"defensive";
    const result=simulateMatch(selectedTeam,nextOpponent,homeFat,awayFat,tactics,aiT);
    setMatchData(result);
    setOpponent(nextOpponent);
  }

  // ── FECHAR PARTIDA ───────────────────────────────────────────────────────
  function handleMatchClose(subs: SubstitutionRecord[]) {
    if(!matchData||!opponent) return;
    const isWin=matchData.homeGoals>matchData.awayGoals;
    const isDraw=matchData.homeGoals===matchData.awayGoals;

    // Ajusta fadiga: jogadores substituídos saem com menos gasto
    const adjustedDrops={...matchData.fatigueDrops};
    subs.forEach(s=>{
      if(adjustedDrops[s.outId]!==undefined) adjustedDrops[s.outId]=Math.floor(adjustedDrops[s.outId]*0.6);
      // Substituto que entrou: carga leve
      adjustedDrops[s.inId]=Math.floor((adjustedDrops[s.outId]??10)*0.4);
    });

    applyFatigueDrops(adjustedDrops,isWin,isDraw);
    recordLeagueResult(selectedTeam.id,opponent.id,matchData.homeGoals,matchData.awayGoals);
    addMatchRecord({round:currentRound,opponent:opponent.name,homeGoals:matchData.homeGoals,awayGoals:matchData.awayGoals,isHome:true});
    if(isWin) addFunds(500);
    addNews({
      type:'result',
      title:`${selectedTeam.abbreviation} ${matchData.homeGoals}–${matchData.awayGoals} ${opponent.abbreviation}`,
      body:isWin?"Vitória! Ótimo resultado.":isDraw?"Empate. Um ponto conquistado.":"Derrota. Hora de analisar.",
      date:`Rd ${currentRound}`,
    });

    // Simular partidas dos outros times desta rodada
    simulateAIRound();

    advanceRound();

    // Auto-save após partida
    if (settings.autoSave === 'after_match' && selectedTeam) {
      setTimeout(() => {
        const data = buildSaveData();
        if (data) saveGame(settings.autoSaveSlot, data, selectedTeam.name, selectedTeam.abbreviation);
      }, 200);
    }

    setTrainingDone(false);
    setMatchData(null);
    setOpponent(null);
  }

  // ── TREINAMENTO ──────────────────────────────────────────────────────────
  function handleTraining() {
    applyTraining();
    setTrainingDone(true);
  }

  const posOrder: Record<string,number> = {GK:0,CB:1,LB:2,RB:3,CDM:4,CM:5,CAM:6,LM:7,RM:8,LW:9,RW:10,ST:11};

  const filteredPlayers = useMemo(()=>{
    let list = selectedTeam.players.filter(p=>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.position.toLowerCase().includes(searchQuery.toLowerCase())
    );
    list = [...list].sort((a,b)=>{
      const sa = playerStates[a.id];
      const sb = playerStates[b.id];
      switch(squadSort){
        case "position":  return (posOrder[a.position]??99)-(posOrder[b.position]??99);
        case "salary":    return b.salary-a.salary;
        case "fatigue":   return (sb?.fatigue??100)-(sa?.fatigue??100);
        case "age":       return a.age-b.age;
        case "name":      return a.name.localeCompare(b.name);
        default:          return b.overall-a.overall;
      }
    });
    return list;
  },[selectedTeam.players, searchQuery, squadSort, playerStates]);

  // Lineup automático: 11 melhores disponíveis
  const autoLineup = useMemo(()=>
    [...selectedTeam.players]
      .filter(p=>(playerStates[p.id]?.injuryWeeks??0)===0)
      .sort((a,b)=>b.overall-a.overall)
      .slice(0,11)
      .map(p=>p.id)
  ,[selectedTeam.players, playerStates]);

  const activeLineup = lineupMode==="manual" && lineup.length===11 ? lineup : autoLineup;
  const sortedStandings = sortStandings(standings);
  const myStanding = sortedStandings.find(s=>s.teamId===selectedTeam.id);
  const myPos = sortedStandings.findIndex(s=>s.teamId===selectedTeam.id)+1;

  const tabs: {key:Tab;icon:string;label:string}[]=[
    {key:"dashboard",icon:"📊",label:"Início"},
    {key:"squad",icon:"👥",label:"Elenco"},
    {key:"tactics",icon:"🎯",label:"Táticas"},
    {key:"training",icon:"🏋️",label:"Treino"},
    {key:"finances",icon:"💰",label:"Finanças"},
    {key:"competitions",icon:"🏆",label:"Liga"},
    {key:"transfers",icon:"🔄",label:"Mercado"},
    {key:"news",icon:"📰",label:"Notícias"},
    {key:"history",icon:"⏱️",label:"Histórico"},
  ];

  return (
    <>
      {matchData && opponent && (
        <MatchScreen homeTeam={selectedTeam} awayTeam={opponent} result={matchData}
          playerStates={playerStates}
          onClose={handleMatchClose}/>
      )}
      {/* CONTRACT MODAL */}
      {showContractModal && (()=>{
        const p = showContractModal;
        const state = playerStates[p.id];
        return (
          <div className="fixed inset-0 z-50 bg-black/60 flex items-end justify-center">
            <div className={`w-full max-w-md rounded-t-2xl border-t border-x p-5 ${dark?"bg-gray-900 border-gray-700":"bg-white border-gray-200"}`}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className={`text-base font-bold ${tx}`}>{p.name}</p>
                  <p className={`text-xs ${sub}`}>{p.position} · {p.age} anos · OVR {p.overall}</p>
                </div>
                <button onClick={()=>setShowContractModal(null)} className={`text-xl ${sub}`}>✕</button>
              </div>
              <div className={`rounded-xl border p-4 mb-4 ${dark?"border-gray-700":"border-gray-200"}`}>
                <div className="grid grid-cols-2 gap-3 text-center">
                  {[
                    {label:"Salário",   val:`${fmtMoney(p.salary)}/mês`,   color:dark?"text-red-400":"text-red-600"},
                    {label:"Contrato",  val:`${p.contractYears} ano(s)`,   color:tx},
                    {label:"Condição",  val:`${state?.fatigue??100}%`,      color:fatigueColor(state?.fatigue??100,dark)},
                    {label:"Moral",     val:moraleLabel(state?.morale??75), color:moraleColor(state?.morale??75,dark)},
                    {label:"Status",    val:statusLabel(p.status),          color:tx},
                    {label:"Personalidade", val:p.personality,             color:sub},
                  ].map(item=>(
                    <div key={item.label} className={`rounded-lg p-2 ${dark?"bg-gray-800":"bg-gray-50"}`}>
                      <p className={`text-xs ${sub}`}>{item.label}</p>
                      <p className={`text-sm font-bold ${item.color}`}>{item.val}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button className={`py-3 rounded-xl text-sm font-bold ${dark?"bg-green-900/50 border border-green-700 text-green-300":"bg-green-50 border border-green-400 text-green-700"}`}
                  onClick={()=>setShowContractModal(null)}>
                  ✓ Renovar contrato
                </button>
                <button className={`py-3 rounded-xl text-sm font-bold ${dark?"bg-blue-900/50 border border-blue-700 text-blue-300":"bg-blue-50 border border-blue-400 text-blue-700"}`}
                  onClick={()=>setShowContractModal(null)}>
                  🔄 Emprestar
                </button>
              </div>
              <button className={`w-full mt-2 py-2 rounded-xl text-xs ${dark?"text-red-400":"text-red-600"}`}>
                Rescindir contrato
              </button>
            </div>
          </div>
        );
      })()}
      )}

      <div className={`min-h-screen flex flex-col ${bg}`}>

        {/* MODAL SALVAR */}
        {saveSlotModal && (
          <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center px-6">
            <div className={`w-full max-w-xs rounded-2xl border p-5 ${dark?"bg-gray-900 border-gray-700":"bg-white border-gray-200"}`}>
              <div className="flex items-center justify-between mb-4">
                <p className={`text-base font-bold ${tx}`}>Salvar Jogo</p>
                <button onClick={()=>setSaveSlotModal(false)} className={`text-xl ${sub}`}>✕</button>
              </div>
              <div className="space-y-2">
                {[1,2,3].map(slot=>{
                  const info = (() => { try { const r=localStorage.getItem(`elite_manager_save_${slot}_meta`); return r?JSON.parse(r):null; } catch{return null;} })();
                  return (
                    <button key={slot} onClick={()=>handleManualSave(slot)}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-colors ${dark?"border-gray-700 bg-gray-800 hover:bg-gray-700":"border-gray-200 bg-gray-50 hover:bg-gray-100"}`}>
                      <div className="text-left">
                        <p className={`text-sm font-bold ${tx}`}>Slot {slot}</p>
                        {info
                          ? <p className={`text-xs ${sub}`}>{info.teamName} · Rd {info.round}</p>
                          : <p className={`text-xs ${sub}`}>Vazio</p>}
                      </div>
                      <span className={`text-xs font-bold ${dark?"text-green-400":"text-green-600"}`}>Salvar aqui</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TOAST */}
        {lastSaveMsg && (
          <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-green-600 text-white text-xs font-bold px-5 py-2 rounded-full shadow-lg pointer-events-none">
            ✓ {lastSaveMsg}
          </div>
        )}

        {/* TOP BAR */}
        <div className={`sticky top-0 z-40 ${dark?"bg-gray-900 border-gray-700":"bg-white border-gray-200"} border-b px-4 py-3`}>
          <div className="flex items-center justify-between max-w-2xl mx-auto">
            <div className="flex items-center gap-2">
              <button onClick={()=>navigate("/")}
                className={`text-xs px-2 py-1.5 rounded-lg border ${dark?"border-gray-700 text-gray-400":"border-gray-300 text-gray-500"}`}>
                ← Menu
              </button>
              <div className="w-8 h-8 flex-shrink-0">{teamLogos[selectedTeam.id]}</div>
              <div>
                <p className={`font-bold text-sm leading-tight ${tx}`}>{selectedTeam.abbreviation}</p>
                <p className={`text-xs ${sub}`}>Rd {currentRound} · {season}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={()=>setSaveSlotModal(true)}
                className={`text-xs px-2 py-1.5 rounded-lg border ${dark?"border-gray-700 text-gray-400 hover:bg-gray-800":"border-gray-300 text-gray-500 hover:bg-gray-50"}`}>
                💾
              </button>
              <div className="text-right">
                <p className={`text-xs font-bold ${dark?"text-green-400":"text-green-600"}`}>{fmtMoney(balance)}</p>
                <p className={`text-xs ${sub}`}>{myPos}º lugar</p>
              </div>
              <button onClick={handleContinue}
                className="bg-green-600 active:bg-green-700 text-white text-xs font-bold px-4 py-2 rounded-lg">
                Jogar →
              </button>
            </div>
          </div>
        </div>

        {/* CONTEÚDO */}
        <div className="flex-1 overflow-y-auto pb-24 max-w-2xl mx-auto w-full">
          <div className="px-4 pt-4">

            {/* ── DASHBOARD ─────────────────────────────────────────────── */}
            {activeTab==="dashboard" && (
              <div className="space-y-4">
                <h2 className={`text-base font-bold ${tx}`}>Dashboard</h2>

                <div className={`rounded-xl border p-4 ${card}`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide ${sub} mb-2`}>Próximo jogo · Rd {currentRound}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8">{teamLogos[selectedTeam.id]}</div>
                      <p className={`font-bold text-sm ${tx}`}>{selectedTeam.abbreviation}</p>
                    </div>
                    <p className={`text-xs font-bold ${sub}`}>vs</p>
                    <div className="flex items-center gap-2">
                      <p className={`font-bold text-sm ${tx}`}>{nextOpponent?.abbreviation}</p>
                      <div className="w-8 h-8">{nextOpponent?teamLogos[nextOpponent.id]:null}</div>
                    </div>
                  </div>
                  <button onClick={handleContinue}
                    className="mt-3 w-full bg-green-600 active:bg-green-700 text-white py-2 rounded-lg text-sm font-bold">
                    Jogar partida
                  </button>
                </div>

                <div className={`rounded-xl border p-4 ${card}`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide ${sub} mb-3`}>Finanças</p>
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <p className={`text-lg font-black ${dark?"text-green-400":"text-green-600"}`}>{fmtMoney(balance)}</p>
                      <p className={`text-xs ${sub}`}>Saldo</p>
                    </div>
                    <div>
                      <p className={`text-lg font-black ${dark?"text-blue-400":"text-blue-600"}`}>{fmtMoney(monthlyIncome)}</p>
                      <p className={`text-xs ${sub}`}>Receita/mês</p>
                    </div>
                    <div>
                      <p className={`text-lg font-black ${dark?"text-red-400":"text-red-600"}`}>{fmtMoney(wageBill)}</p>
                      <p className={`text-xs ${sub}`}>Folha/mês</p>
                    </div>
                  </div>
                </div>

                <div className={`rounded-xl border p-4 ${card}`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide ${sub} mb-3`}>Campeonato</p>
                  {myStanding&&(
                    <div className="flex items-center justify-between">
                      <div className="text-center">
                        <p className={`text-3xl font-black ${tx}`}>{myPos}º</p>
                        <p className={`text-xs ${sub}`}>Posição</p>
                      </div>
                      <div className="text-center">
                        <p className={`text-3xl font-black ${dark?"text-yellow-300":"text-yellow-600"}`}>{myStanding.points}</p>
                        <p className={`text-xs ${sub}`}>Pontos</p>
                      </div>
                      <div className="text-center">
                        <p className={`text-lg font-bold ${tx}`}>{myStanding.won}V {myStanding.drawn}E {myStanding.lost}D</p>
                        <p className={`text-xs ${sub}`}>{myStanding.played} jogos</p>
                      </div>
                      <div className="flex gap-1">
                        {myStanding.form.map((f,i)=>(
                          <div key={i} className={`w-5 h-5 rounded text-xs font-bold flex items-center justify-center ${f==="W"?"bg-green-600 text-white":f==="D"?"bg-yellow-600 text-white":"bg-red-600 text-white"}`}>{f}</div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className={`rounded-xl border p-4 ${card}`}>
                  <p className={`text-xs ${sub} mb-1`}>Objetivo da temporada</p>
                  <p className={`text-sm font-semibold ${tx}`}>{selectedTeam.objective}</p>
                </div>

                {news.slice(0,3).map(n=>(
                  <div key={n.id} className={`rounded-xl border p-3 ${card}`}>
                    <div className="flex gap-2">
                      <span className="text-lg">{n.type==="result"?"⚽":n.type==="injury"?"🤕":n.type==="training"?"🏋️":"📢"}</span>
                      <div>
                        <p className={`text-xs font-bold ${tx}`}>{n.title}</p>
                        <p className={`text-xs ${sub}`}>{n.body}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ── ELENCO ────────────────────────────────────────────────── */}
            {activeTab==="squad" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Elenco</h2>

                {/* Busca */}
                <input type="text" placeholder="Buscar jogador..." value={searchQuery}
                  onChange={e=>setSearchQuery(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm mb-3 ${dark?"bg-gray-800 border-gray-700 text-white placeholder-gray-500":"bg-white border-gray-300 text-gray-900 placeholder-gray-400"}`}/>

                {/* Ordenação */}
                <div className="flex gap-1.5 flex-wrap mb-3">
                  {([
                    {k:"overall",  label:"OVR"},
                    {k:"position", label:"Pos"},
                    {k:"salary",   label:"Salário"},
                    {k:"fatigue",  label:"Cond"},
                    {k:"age",      label:"Idade"},
                    {k:"name",     label:"Nome"},
                  ] as {k:typeof squadSort;label:string}[]).map(o=>(
                    <button key={o.k} onClick={()=>setSquadSort(o.k)}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                        squadSort===o.k
                          ? dark?"bg-white text-black":"bg-gray-900 text-white"
                          : dark?"bg-gray-800 text-gray-400":"bg-gray-100 text-gray-600"
                      }`}>{o.label}</button>
                  ))}
                </div>

                {/* Modo de escalação */}
                <div className={`rounded-xl border p-3 mb-3 ${card}`}>
                  <div className="flex items-center justify-between mb-2">
                    <p className={`text-xs font-semibold ${sub}`}>Escalação</p>
                    <div className="flex gap-1">
                      <button onClick={()=>setLineupMode("auto")}
                        className={`px-3 py-1 rounded-lg text-xs font-bold ${lineupMode==="auto"?(dark?"bg-white text-black":"bg-gray-900 text-white"):dark?"bg-gray-700 text-gray-300":"bg-gray-200 text-gray-600"}`}>
                        Auto
                      </button>
                      <button onClick={()=>{ setLineupMode("manual"); setLineup(autoLineup); }}
                        className={`px-3 py-1 rounded-lg text-xs font-bold ${lineupMode==="manual"?(dark?"bg-white text-black":"bg-gray-900 text-white"):dark?"bg-gray-700 text-gray-300":"bg-gray-200 text-gray-600"}`}>
                        Manual
                      </button>
                    </div>
                  </div>
                  {lineupMode==="manual" && (
                    <p className={`text-xs ${sub}`}>
                      Toque no jogador para marcar/desmarcar como titular.
                      Titulares: <span className={`font-bold ${activeLineup.length===11?(dark?"text-green-400":"text-green-600"):(dark?"text-yellow-400":"text-yellow-600")}`}>{activeLineup.length}/11</span>
                    </p>
                  )}
                </div>

                {/* Lista */}
                <div className="space-y-2">
                  {filteredPlayers.map(player=>{
                    const state=playerStates[player.id]??{fatigue:100,morale:75,happiness:75,injuryWeeks:0};
                    const injured=state.injuryWeeks>0;
                    const isInLineup=activeLineup.includes(player.id);

                    function toggleLineup(){
                      if(lineupMode!=="manual") return;
                      setLineup(prev=>{
                        if(prev.includes(player.id)) return prev.filter(id=>id!==player.id);
                        if(prev.length>=11) return prev;
                        return [...prev, player.id];
                      });
                    }

                    return (
                      <div key={player.id} className={`rounded-xl border transition-colors ${card} ${injured?"border-red-500/50":isInLineup&&lineupMode==="manual"?"border-green-500/50":""}`}>
                        <button onClick={()=>lineupMode==="manual"?toggleLineup():setSelectedPlayer(player)}
                          className="w-full flex items-center gap-3 p-3 text-left">
                          {/* Badge titular */}
                          <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                            injured?"bg-red-900/50 text-red-400":
                            isInLineup?(dark?"bg-green-900/50 text-green-300":"bg-green-100 text-green-700"):
                            dark?"bg-gray-700 text-white":"bg-gray-100 text-gray-800"
                          }`}>
                            {player.position}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className={`text-sm font-semibold truncate ${tx} ${injured?"line-through opacity-50":""}`}>{player.name}</p>
                              <span className={`text-sm font-black ml-2 flex-shrink-0 ${player.overall>=80?(dark?"text-green-400":"text-green-600"):player.overall>=70?(dark?"text-blue-400":"text-blue-600"):tx}`}>{player.overall}</span>
                            </div>
                            <div className="flex gap-2 mt-0.5 flex-wrap">
                              <span className={`text-xs ${sub}`}>{player.age}a</span>
                              {/* Barra de fadiga */}
                              <div className="flex items-center gap-1">
                                <div className={`w-12 h-1.5 rounded-full ${dark?"bg-gray-700":"bg-gray-200"}`}>
                                  <div className={`h-1.5 rounded-full ${state.fatigue>=70?"bg-green-500":state.fatigue>=40?"bg-yellow-500":"bg-red-500"}`}
                                    style={{width:`${state.fatigue}%`}}/>
                                </div>
                                <span className={`text-xs font-semibold ${fatigueColor(state.fatigue,dark)}`}>{state.fatigue}%</span>
                              </div>
                              <span className={`text-xs ${moraleColor(state.morale,dark)}`}>{moraleLabel(state.morale)}</span>
                              {injured && <span className="text-xs text-red-400">🤕 {state.injuryWeeks}sem</span>}
                              {isInLineup && lineupMode==="manual" && <span className={`text-xs ${dark?"text-green-400":"text-green-600"} font-bold`}>✓ Titular</span>}
                            </div>
                          </div>
                        </button>
                        {/* Contrato info + botão */}
                        <div className={`flex items-center justify-between px-3 pb-2 border-t ${div} pt-1.5`}>
                          <span className={`text-xs ${sub}`}>
                            {fmtMoney(player.salary)}/mês · {player.contractYears} ano(s)
                          </span>
                          <button onClick={()=>setShowContractModal(player)}
                            className={`text-xs px-2 py-0.5 rounded border ${dark?"border-gray-600 text-gray-400":"border-gray-300 text-gray-500"}`}>
                            Contrato
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── TÁTICAS ───────────────────────────────────────────────── */}
            {activeTab==="tactics" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Táticas</h2>

                {/* CAMPO COM BLOCOS */}
                <div className={`rounded-xl border p-3 mb-4 ${card}`}>
                  <div className="flex items-center justify-between mb-2">
                    <p className={`text-xs font-semibold uppercase tracking-wide ${sub}`}>Formação</p>
                    <p className={`text-sm font-black ${tx}`}>{formation}</p>
                  </div>

                  {/* Seletor de formação */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {(["4-4-2","4-3-3","4-2-3-1","3-5-2","5-3-2","4-5-1"] as Formation[]).map(f=>(
                      <button key={f} onClick={()=>setFormation(f)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                          formation===f
                            ? dark?"bg-white text-black border-white":"bg-gray-900 text-white border-gray-900"
                            : dark?"border-gray-600 text-gray-400":"border-gray-300 text-gray-600"
                        }`}>{f}</button>
                    ))}
                  </div>

                  {/* Campo visual */}
                  <FormationField formation={formation} dark={dark}/>
                </div>

                {/* OPÇÕES TÁTICAS */}
                <div className={`rounded-xl border p-4 ${card}`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide ${sub} mb-2`}>Instruções táticas</p>
                  <TacticsPanel tactics={tactics} setTactics={setTactics} dark={dark}/>
                </div>
              </div>
            )}

            {/* ── TREINAMENTO ───────────────────────────────────────────── */}
            {activeTab==="training" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Treinamento</h2>

                <div className={`rounded-xl border p-4 ${card} mb-4`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide ${sub} mb-3`}>Foco do treino</p>
                  <div className="grid grid-cols-2 gap-2">
                    {([
                      {k:"physical",  label:"🏃 Físico",   desc:"Recupera fadiga"},
                      {k:"technical", label:"⚽ Técnico",  desc:"Melhora atributos"},
                      {k:"tactical",  label:"🎯 Tático",   desc:"Entrosamento"},
                      {k:"rest",      label:"😴 Descanso", desc:"Recuperação máxima"},
                      {k:"youth",     label:"⭐ Base",     desc:"Foco em jovens"},
                    ] as {k:TrainingFocus;label:string;desc:string}[]).map(o=>(
                      <button key={o.k} onClick={()=>setTrainingFocus(o.k)}
                        className={`rounded-xl p-3 border text-left transition-colors ${
                          trainingFocus===o.k
                            ? dark?"bg-green-900/50 border-green-500":"bg-green-50 border-green-500"
                            : dark?"bg-gray-700 border-gray-600":"bg-gray-50 border-gray-200"
                        }`}>
                        <p className={`text-xs font-bold ${trainingFocus===o.k?(dark?"text-green-300":"text-green-700"):tx}`}>{o.label}</p>
                        <p className={`text-xs mt-0.5 ${sub}`}>{o.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <div className={`rounded-xl border p-4 ${card} mb-4`}>
                  <p className={`text-xs font-semibold uppercase tracking-wide ${sub} mb-3`}>Intensidade</p>
                  <div className="flex gap-2">
                    {([
                      {k:"light", label:"Leve",desc:"-3% fadiga"},
                      {k:"normal",label:"Normal",desc:"-7% fadiga"},
                      {k:"hard",  label:"Pesado",desc:"-14% fadiga"},
                    ] as {k:TrainingIntensity;label:string;desc:string}[]).map(o=>(
                      <button key={o.k} onClick={()=>setTrainingIntensity(o.k)}
                        className={`flex-1 rounded-xl p-3 border text-center transition-colors ${
                          trainingIntensity===o.k?"bg-white text-black border-white":dark?"bg-gray-700 border-gray-600 text-gray-300":"bg-gray-50 border-gray-200 text-gray-700"
                        }`}>
                        <p className="text-xs font-bold">{o.label}</p>
                        <p className="text-xs opacity-70">{o.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {trainingDone && (
                  <div className={`rounded-xl border p-3 mb-3 ${dark?"border-green-700 bg-green-900/30":"border-green-300 bg-green-50"}`}>
                    <p className={`text-xs font-semibold ${dark?"text-green-400":"text-green-700"}`}>✅ Treino realizado! Fadiga e moral atualizados.</p>
                  </div>
                )}

                <button onClick={handleTraining}
                  className={`w-full py-3 rounded-xl font-bold text-sm ${trainingDone?"bg-gray-600 text-gray-400":"bg-green-600 active:bg-green-700 text-white"}`}>
                  {trainingDone ? "Treino já realizado esta semana" : "Realizar treino semanal"}
                </button>

                {selectedTeam.players.filter(p=>(playerStates[p.id]?.injuryWeeks??0)>0).length>0 && (
                  <div className={`rounded-xl border p-4 ${card} mt-4`}>
                    <p className={`text-xs font-semibold uppercase tracking-wide ${sub} mb-2`}>Jogadores lesionados</p>
                    {selectedTeam.players.filter(p=>(playerStates[p.id]?.injuryWeeks??0)>0).map(p=>(
                      <div key={p.id} className="flex justify-between py-1.5">
                        <p className={`text-sm ${tx}`}>{p.name}</p>
                        <p className="text-xs text-red-400">🤕 {playerStates[p.id].injuryWeeks} sem</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ── FINANÇAS ──────────────────────────────────────────────── */}
            {activeTab==="finances" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Finanças</h2>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  {[
                    {label:"Saldo",val:balance,color:dark?"text-green-400":"text-green-600"},
                    {label:"Receita/mês",val:monthlyIncome,color:dark?"text-blue-400":"text-blue-600"},
                    {label:"Folha/mês",val:wageBill,color:dark?"text-red-400":"text-red-600"},
                    {label:"Resultado/mês",val:monthlyIncome-wageBill,color:(monthlyIncome-wageBill)>=0?(dark?"text-green-400":"text-green-600"):(dark?"text-red-400":"text-red-600")},
                  ].map(item=>(
                    <div key={item.label} className={`rounded-xl border p-4 ${card}`}>
                      <p className={`text-xs ${sub} mb-1`}>{item.label}</p>
                      <p className={`text-xl font-black ${item.color}`}>{fmtMoney(item.val)}</p>
                    </div>
                  ))}
                </div>
                <div className={`rounded-xl border p-4 ${card} mb-3`}>
                  <p className={`text-xs ${sub} mb-1`}>Nível do clube</p>
                  <p className={`text-sm font-bold ${tx}`}>{levelLabel(selectedTeam.clubLevel)} (Nível {selectedTeam.clubLevel})</p>
                </div>
                <div className={`rounded-xl border overflow-hidden ${card}`}>
                  <div className={`px-4 py-2.5 border-b ${div}`}>
                    <p className={`text-xs font-semibold uppercase tracking-wide ${sub}`}>Maiores salários</p>
                  </div>
                  {[...selectedTeam.players].sort((a,b)=>b.salary-a.salary).slice(0,8).map(p=>(
                    <div key={p.id} className={`flex justify-between px-4 py-2.5 border-b ${div} last:border-0`}>
                      <div>
                        <p className={`text-sm ${tx}`}>{p.name}</p>
                        <p className={`text-xs ${sub}`}>{p.position} · {statusLabel(p.status)}</p>
                      </div>
                      <p className={`text-sm font-bold ${dark?"text-red-400":"text-red-600"}`}>{fmtMoney(p.salary)}/mês</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── LIGA ──────────────────────────────────────────────────── */}
            {activeTab==="competitions" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Campeonato {season}</h2>
                <div className={`rounded-xl border overflow-hidden ${card}`}>
                  <div className={`px-3 py-2 border-b ${div} grid text-xs font-semibold ${sub}`}
                    style={{gridTemplateColumns:"1.5rem 1fr 2rem 2rem 2rem 2rem 2rem 2.5rem"}}>
                    <span>#</span><span>Time</span><span className="text-center">J</span>
                    <span className="text-center">V</span><span className="text-center">E</span>
                    <span className="text-center">D</span><span className="text-center">SG</span>
                    <span className="text-center font-black">Pts</span>
                  </div>
                  {sortedStandings.map((row,idx)=>{
                    const isMe=row.teamId===selectedTeam.id;
                    const gd=row.goalsFor-row.goalsAgainst;
                    return (
                      <div key={row.teamId}
                        className={`px-3 py-2.5 border-b ${div} last:border-0 grid items-center text-xs ${isMe?dark?"bg-green-900/30":"bg-green-50":""}`}
                        style={{gridTemplateColumns:"1.5rem 1fr 2rem 2rem 2rem 2rem 2rem 2.5rem"}}>
                        <span className={`font-bold ${idx<4?(dark?"text-green-400":"text-green-600"):idx>=17?(dark?"text-red-400":"text-red-600"):sub}`}>{idx+1}</span>
                        <span className={`font-semibold truncate ${isMe?(dark?"text-green-300":"text-green-700"):tx}`}>{row.teamAbbr}</span>
                        <span className={`text-center ${sub}`}>{row.played}</span>
                        <span className={`text-center ${dark?"text-green-400":"text-green-600"}`}>{row.won}</span>
                        <span className={`text-center ${dark?"text-yellow-400":"text-yellow-600"}`}>{row.drawn}</span>
                        <span className={`text-center ${dark?"text-red-400":"text-red-600"}`}>{row.lost}</span>
                        <span className={`text-center ${sub}`}>{gd>=0?`+${gd}`:gd}</span>
                        <span className={`text-center font-black ${isMe?(dark?"text-green-300":"text-green-700"):tx}`}>{row.points}</span>
                      </div>
                    );
                  })}
                </div>
                <p className={`text-xs ${sub} mt-2 text-center`}>Verde = continental · Vermelho = rebaixamento</p>
              </div>
            )}

            {/* ── MERCADO ───────────────────────────────────────────────── */}
            {activeTab==="transfers" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Mercado</h2>
                <div className={`rounded-xl border p-4 ${card} mb-4 text-center`}>
                  <p className="text-3xl mb-2">🔄</p>
                  <p className={`text-sm font-semibold ${tx}`}>Em desenvolvimento</p>
                  <p className={`text-xs ${sub} mt-1`}>Negociações, jogadores livres e contratos em breve.</p>
                </div>
                <div className={`rounded-xl border ${card}`}>
                  <div className={`px-4 py-2.5 border-b ${div}`}>
                    <p className={`text-xs font-semibold uppercase tracking-wide ${sub}`}>Contratos a vencer</p>
                  </div>
                  {selectedTeam.players.filter(p=>p.contractYears<=1).map(p=>(
                    <div key={p.id} className={`flex justify-between px-4 py-2.5 border-b ${div} last:border-0`}>
                      <div>
                        <p className={`text-sm ${tx}`}>{p.name}</p>
                        <p className={`text-xs ${sub}`}>{p.position} · OVR {p.overall}</p>
                      </div>
                      <p className={`text-xs font-semibold ${dark?"text-yellow-400":"text-yellow-600"}`}>
                        {p.contractYears===0?"Livre em breve":`${p.contractYears} ano`}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── NOTÍCIAS ──────────────────────────────────────────────── */}
            {activeTab==="news" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Notícias</h2>
                {news.length===0
                  ? <p className={`text-sm ${sub}`}>Nenhuma notícia ainda.</p>
                  : <div className="space-y-3">
                      {news.map(n=>(
                        <div key={n.id} className={`rounded-xl border p-3 ${card}`}>
                          <div className="flex gap-3">
                            <span className="text-xl flex-shrink-0">{n.type==="result"?"⚽":n.type==="injury"?"🤕":n.type==="training"?"🏋️":"📢"}</span>
                            <div>
                              <div className="flex gap-2 mb-0.5">
                                <p className={`text-xs font-bold ${tx}`}>{n.title}</p>
                                <span className={`text-xs ${sub}`}>· {n.date}</span>
                              </div>
                              <p className={`text-xs ${sub}`}>{n.body}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                }
              </div>
            )}

            {/* ── HISTÓRICO ─────────────────────────────────────────────── */}
            {activeTab==="history" && (
              <div>
                <h2 className={`text-base font-bold mb-3 ${tx}`}>Histórico</h2>
                {matchHistory.length===0
                  ? <p className={`text-sm ${sub}`}>Nenhuma partida disputada.</p>
                  : <div className="space-y-2">
                      {matchHistory.map((m,i)=>{
                        const isWin=m.homeGoals>m.awayGoals,isDraw=m.homeGoals===m.awayGoals;
                        return (
                          <div key={i} className={`flex items-center gap-3 rounded-xl border px-4 py-3 ${card}`}>
                            <span className={`w-10 text-center text-xs font-black px-2 py-1 rounded-lg ${isWin?"bg-green-600 text-white":isDraw?"bg-yellow-600 text-white":"bg-red-600 text-white"}`}>
                              {isWin?"VIT":isDraw?"EMP":"DER"}
                            </span>
                            <span className={`text-xs ${sub} w-8`}>Rd {m.round}</span>
                            <span className={`flex-1 text-sm font-semibold ${tx}`}>
                              {selectedTeam.abbreviation} {m.homeGoals}–{m.awayGoals} {m.opponent.slice(0,12)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                }
              </div>
            )}

          </div>
        </div>

        {/* BOTTOM NAV */}
        <div className={`fixed bottom-0 left-0 right-0 z-40 ${dark?"bg-gray-900 border-gray-700":"bg-white border-gray-200"} border-t`}>
          <div className="flex overflow-x-auto max-w-2xl mx-auto">
            {tabs.map(tab=>(
              <button key={tab.key} onClick={()=>setActiveTab(tab.key)}
                className={`flex flex-col items-center flex-shrink-0 px-3 py-2 min-w-[64px] transition-colors ${
                  activeTab===tab.key?(dark?"text-green-400":"text-green-600"):(dark?"text-gray-500":"text-gray-400")
                }`}>
                <span className="text-lg leading-none">{tab.icon}</span>
                <span className="text-xs mt-0.5 font-medium whitespace-nowrap">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
