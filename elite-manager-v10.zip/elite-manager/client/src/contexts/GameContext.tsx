import {
  createContext, useContext, useState, useCallback, ReactNode, useMemo,
} from "react";
import { Team, Player } from "@/lib/teams";
import { TacticalSettings, defaultTactics } from "@/lib/matchEngine";
import {
  StandingRow, ScheduledMatch, CupMatch,
  generateLeague, generateCup, updateStandings, sortStandings,
} from "@/lib/leagueSystem";
import { teams as allTeams } from "@/lib/teams";

// ─── TIPOS ────────────────────────────────────────────────────────────────────

export interface PlayerState {
  fatigue: number;
  morale: number;
  happiness: number;
  injuryWeeks: number;
}

export interface MatchRecord {
  round: number;
  opponent: string;
  homeGoals: number;
  awayGoals: number;
  isHome: boolean;
}

export interface NewsItem {
  id: number;
  type: 'injury' | 'result' | 'transfer' | 'contract' | 'training' | 'info';
  title: string;
  body: string;
  date: string; // "Rd X"
}

export type TrainingFocus =
  | 'physical'   // recuperação de fadiga rápida
  | 'technical'  // boost em shooting/passing/dribbling
  | 'tactical'   // melhora entrosamento
  | 'rest'       // recuperação máxima
  | 'youth';     // foco em jogadores jovens

interface GameContextType {
  // Time
  selectedTeam: Team | null;
  setSelectedTeam: (team: Team) => void;

  // Estado dinâmico dos jogadores
  playerStates: Record<number, PlayerState>;
  applyFatigueDrops: (drops: Record<number, number>, isWin: boolean, isDraw: boolean) => void;

  // Táticas
  tactics: TacticalSettings;
  setTactics: (t: TacticalSettings) => void;

  // Partidas
  matchHistory: MatchRecord[];
  addMatchRecord: (r: MatchRecord) => void;
  currentRound: number;
  advanceRound: () => void;

  // Finanças
  balance: number;
  monthlyIncome: number;
  wageBill: number;          // folha salarial mensal
  addFunds: (amount: number) => void;
  deductFunds: (amount: number) => void;

  // Liga
  standings: StandingRow[];
  schedule: ScheduledMatch[];
  recordLeagueResult: (homeId: number, awayId: number, hg: number, ag: number) => void;

  // Copa
  cupMatches: CupMatch[];

  // Notícias
  news: NewsItem[];
  addNews: (n: Omit<NewsItem, 'id'>) => void;

  // Treinamento
  trainingFocus: TrainingFocus;
  setTrainingFocus: (f: TrainingFocus) => void;
  trainingIntensity: 'light' | 'normal' | 'hard';
  setTrainingIntensity: (i: 'light' | 'normal' | 'hard') => void;
  applyTraining: () => void;

  // Rodada
  season: number;

  // Save/Load
  restoreFromSave: (team: Team, data: import('@/lib/saveSystem').GameSaveData) => void;
  buildSaveData: () => import('@/lib/saveSystem').GameSaveData | null;
}

// ─── CONTEXTO ─────────────────────────────────────────────────────────────────

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
  const [selectedTeam, setSelectedTeamRaw] = useState<Team | null>(null);
  const [playerStates, setPlayerStates] = useState<Record<number, PlayerState>>({});
  const [tactics, setTactics] = useState<TacticalSettings>(defaultTactics);
  const [matchHistory, setMatchHistory] = useState<MatchRecord[]>([]);
  const [currentRound, setCurrentRound] = useState(1);
  const [balance, setBalance] = useState(0);
  const [monthlyIncome, setMonthlyIncome] = useState(0);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [trainingFocus, setTrainingFocus] = useState<TrainingFocus>('physical');
  const [trainingIntensity, setTrainingIntensity] = useState<'light'|'normal'|'hard'>('normal');
  const [season] = useState(2026);
  const [newsCounter, setNewsCounter] = useState(0);

  // Liga e copa geradas uma vez
  const { standings: initStandings, schedule: initSchedule } = useMemo(
    () => generateLeague(allTeams),
    []
  );
  const initCup = useMemo(() => generateCup(allTeams), []);
  const [standings, setStandings] = useState<StandingRow[]>(initStandings);
  const [schedule] = useState<ScheduledMatch[]>(initSchedule);
  const [cupMatches] = useState<CupMatch[]>(initCup);

  // Folha salarial calculada do time selecionado
  const wageBill = useMemo(() => {
    if (!selectedTeam) return 0;
    return selectedTeam.players.reduce((s, p) => s + p.salary, 0);
  }, [selectedTeam]);

  // Ao selecionar o time
  const setSelectedTeam = useCallback((team: Team) => {
    setSelectedTeamRaw(team);
    setBalance(team.balance);
    setMonthlyIncome(team.monthlyIncome);

    const initial: Record<number, PlayerState> = {};
    team.players.forEach((p: Player) => {
      initial[p.id] = {
        fatigue: 100,
        morale: p.morale,
        happiness: p.happiness,
        injuryWeeks: p.injuryWeeks,
      };
    });
    setPlayerStates(initial);

    // Notícia inicial
    pushNews({
      type: 'info',
      title: `Bem-vindo ao ${team.name}!`,
      body: `Você assumiu o comando do ${team.name}. Objetivo da temporada: ${team.objective}.`,
      date: 'Pré-temporada',
    });
  }, []);

  // Finanças
  const addFunds = useCallback((v: number) => setBalance(b => b + v), []);
  const deductFunds = useCallback((v: number) => setBalance(b => b - v), []);

  // Notícias
  const pushNews = useCallback((n: Omit<NewsItem, 'id'>) => {
    setNewsCounter(c => {
      const id = c + 1;
      setNews(prev => [{ ...n, id }, ...prev].slice(0, 30));
      return id;
    });
  }, []);
  const addNews = pushNews;

  // Fadiga + moral após partida
  const applyFatigueDrops = useCallback(
    (drops: Record<number, number>, isWin: boolean, isDraw: boolean) => {
      setPlayerStates(prev => {
        const next = { ...prev };
        const moraleDelta = isWin ? 6 : isDraw ? 1 : -5;
        const happyDelta  = isWin ? 4 : isDraw ? 0 : -3;

        Object.entries(drops).forEach(([idStr, drop]) => {
          const id = Number(idStr);
          const cur = next[id] ?? { fatigue: 100, morale: 75, happiness: 75, injuryWeeks: 0 };

          // Chance de lesão aumenta com fadiga baixa
          let injury = cur.injuryWeeks;
          if (cur.injuryWeeks === 0) {
            const injChance = Math.max(0, (100 - cur.fatigue) / 400);
            if (Math.random() < injChance) {
              const r = Math.random();
              injury = r < 0.6 ? 1 : r < 0.85 ? 2 : r < 0.95 ? 4 : 8;
            }
          }

          next[id] = {
            fatigue: Math.max(0, cur.fatigue - drop),
            morale: Math.min(100, Math.max(0, cur.morale + moraleDelta)),
            happiness: Math.min(100, Math.max(0, cur.happiness + happyDelta)),
            injuryWeeks: injury,
          };
        });
        return next;
      });
    },
    []
  );

  // Liga: registrar resultado
  const recordLeagueResult = useCallback(
    (homeId: number, awayId: number, hg: number, ag: number) => {
      setStandings(prev => sortStandings(updateStandings(prev, homeId, awayId, hg, ag)));
    },
    []
  );

  // Avança rodada + receita mensal a cada 4 rodadas
  const advanceRound = useCallback(() => {
    setCurrentRound(prev => {
      const next = prev + 1;
      // A cada ~4 rodadas = 1 mês, recebe receita
      if (next % 4 === 0) {
        setBalance(b => b + monthlyIncome);
        pushNews({
          type: 'info',
          title: 'Receita recebida',
          body: `O clube recebeu R$${monthlyIncome.toLocaleString()} mil em receitas mensais.`,
          date: `Rd ${next}`,
        });
        // Desconta folha salarial
        setBalance(b => b - wageBill);
      }
      return next;
    });

    // Recuperação automática de fadiga entre rodadas
    setPlayerStates(prev => {
      const next = { ...prev };
      Object.keys(next).forEach(idStr => {
        const id = Number(idStr);
        const cur = next[id];
        const recovery = trainingFocus === 'rest' ? 28 : trainingFocus === 'physical' ? 20 : 15;
        const injRecover = cur.injuryWeeks > 0 ? cur.injuryWeeks - 1 : 0;
        next[id] = {
          ...cur,
          fatigue: Math.min(100, cur.fatigue + recovery),
          injuryWeeks: injRecover,
        };
      });
      return next;
    });
  }, [monthlyIncome, wageBill, trainingFocus, pushNews]);

  // Adicionar ao histórico
  const addMatchRecord = useCallback((record: MatchRecord) => {
    setMatchHistory(prev => [record, ...prev]);
  }, []);

  // ── RESTORE FROM SAVE ──────────────────────────────────────────────────────
  const restoreFromSave = useCallback((team: Team, data: any) => {
    setSelectedTeamRaw(team);
    setBalance(data.balance ?? team.balance);
    setMonthlyIncome(data.monthlyIncome ?? team.monthlyIncome);
    setCurrentRound(data.currentRound ?? 1);
    setMatchHistory(data.matchHistory ?? []);
    setNews(data.news ?? []);
    setTrainingFocus(data.trainingFocus ?? 'physical');
    setTrainingIntensity(data.trainingIntensity ?? 'normal');
    if (data.tactics) setTactics(data.tactics);
    if (data.playerStates) setPlayerStates(data.playerStates);
    if (data.standings) setStandings(data.standings);
  }, []);

  // ── BUILD SAVE DATA ────────────────────────────────────────────────────────
  const buildSaveData = useCallback((): any | null => {
    if (!selectedTeam) return null;
    return {
      teamId: selectedTeam.id,
      playerStates,
      tactics,
      matchHistory,
      currentRound,
      balance,
      monthlyIncome,
      standings,
      news,
      trainingFocus,
      trainingIntensity,
      season,
      savedAt: new Date().toISOString(),
    };
  }, [selectedTeam, playerStates, tactics, matchHistory, currentRound, balance, monthlyIncome, standings, news, trainingFocus, trainingIntensity, season]);

  // Treinamento semanal
  const applyTraining = useCallback(() => {
    if (!selectedTeam) return;
    setPlayerStates(prev => {
      const next = { ...prev };
      selectedTeam.players.forEach(p => {
        const cur = next[p.id] ?? { fatigue: 100, morale: 75, happiness: 75, injuryWeeks: 0 };
        if (cur.injuryWeeks > 0) return; // lesionado não treina

        let fatChange = 0;  // positivo = recupera, negativo = gasta
        let moraleDelta = 0;

        // Foco determina o efeito principal
        if (trainingFocus === 'rest') {
          // Descanso: recupera fadiga ao máximo, melhora moral
          fatChange = +25;
          moraleDelta = 3;
        } else if (trainingFocus === 'physical') {
          // Físico: recupera fadiga (condicionamento)
          fatChange = +12;
          moraleDelta = 0;
        } else if (trainingFocus === 'technical' || trainingFocus === 'tactical') {
          // Técnico/Tático: gasta energia mas melhora capacidade
          fatChange = -5;
          moraleDelta = 1;
        } else if (trainingFocus === 'youth') {
          fatChange = p.age <= 22 ? -3 : -6;
          moraleDelta = p.age <= 22 ? 2 : 0;
        }

        // Intensidade modifica o efeito
        switch (trainingIntensity) {
          case 'light':
            fatChange = trainingFocus === 'rest' || trainingFocus === 'physical'
              ? fatChange + 5    // recupera mais
              : fatChange + 3;   // gasta menos
            break;
          case 'hard':
            fatChange = trainingFocus === 'rest' || trainingFocus === 'physical'
              ? fatChange - 5    // recupera menos (treino pesado até no descanso)
              : fatChange - 8;   // gasta muito mais
            moraleDelta -= 2;
            break;
        }

        next[p.id] = {
          ...cur,
          fatigue: Math.min(100, Math.max(0, cur.fatigue + fatChange)),
          morale: Math.min(100, Math.max(0, cur.morale + moraleDelta)),
        };
      });
      return next;
    });

    const focusLabel: Record<string,string> = {
      physical:'Físico (Recuperação)', technical:'Técnico', tactical:'Tático',
      rest:'Descanso', youth:'Base'
    };
    pushNews({
      type: 'training',
      title: 'Treino realizado',
      body: `Sessão ${trainingIntensity === 'hard' ? 'pesada' : trainingIntensity === 'light' ? 'leve' : 'normal'} — Foco: ${focusLabel[trainingFocus] ?? trainingFocus}.`,
      date: `Rd ${currentRound}`,
    });
  }, [selectedTeam, trainingFocus, trainingIntensity, currentRound, pushNews]);

  return (
    <GameContext.Provider value={{
      selectedTeam, setSelectedTeam,
      playerStates, applyFatigueDrops,
      tactics, setTactics,
      matchHistory, addMatchRecord,
      currentRound, advanceRound,
      balance, monthlyIncome, wageBill,
      addFunds, deductFunds,
      standings, schedule, recordLeagueResult,
      cupMatches,
      news, addNews,
      trainingFocus, setTrainingFocus,
      trainingIntensity, setTrainingIntensity,
      applyTraining,
      season,
      restoreFromSave,
      buildSaveData,
    }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error("useGame must be used within GameProvider");
  return ctx;
}
